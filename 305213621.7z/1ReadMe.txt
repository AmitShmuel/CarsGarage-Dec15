if you are running the program through the command prompt

you might need to give full path to the txt files as well

i.e: 305213621\CarClassNew.exe 305213621\Cars.txt 305213621\Customers.txt

and NOT -

305213621\CarClassNew.exe Cars.txt Customers.txt


in any case, please make sure the Cars.txt comes before Customers.txt,
otherwise the program will be messed up.

THANK YOU !