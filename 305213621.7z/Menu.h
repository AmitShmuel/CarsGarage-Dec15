#ifndef _MENU_
#define _MENU_
#include "Garage.h"


void printWelcome(Garage*);

void printBye();

void printErr();

void Case1(Garage*);

void Case2(Garage*);

void Case3(Garage*);


#endif
